﻿namespace Cookbook
{
    partial class DishAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtDescription = new TextBox();
            label1 = new Label();
            label2 = new Label();
            CreateButton = new Button();
            dataGridView_AvIng = new DataGridView();
            dataGridView_SelIng = new DataGridView();
            label3 = new Label();
            label4 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel2 = new TableLayoutPanel();
            pictureBoxDish = new PictureBox();
            tableLayoutPanel3 = new TableLayoutPanel();
            btnBrowse = new Button();
            btnRemovePic = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView_AvIng).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_SelIng).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxDish).BeginInit();
            tableLayoutPanel3.SuspendLayout();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtName.Location = new Point(136, 5);
            txtName.Margin = new Padding(4, 5, 4, 5);
            txtName.Name = "txtName";
            txtName.Size = new Size(538, 31);
            txtName.TabIndex = 0;
            // 
            // txtDescription
            // 
            txtDescription.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtDescription.Location = new Point(136, 52);
            txtDescription.Margin = new Padding(4, 5, 4, 5);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(538, 31);
            txtDescription.TabIndex = 1;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(126, 47);
            label1.TabIndex = 2;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(3, 47);
            label2.Name = "label2";
            label2.Size = new Size(126, 48);
            label2.TabIndex = 3;
            label2.Text = "Description";
            // 
            // CreateButton
            // 
            CreateButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            CreateButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            CreateButton.Location = new Point(488, 558);
            CreateButton.Name = "CreateButton";
            CreateButton.Size = new Size(480, 60);
            CreateButton.TabIndex = 4;
            CreateButton.Text = "Create";
            CreateButton.UseVisualStyleBackColor = true;
            CreateButton.Click += CreateButton_Click;
            // 
            // dataGridView_AvIng
            // 
            dataGridView_AvIng.AllowUserToAddRows = false;
            dataGridView_AvIng.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_AvIng.Dock = DockStyle.Fill;
            dataGridView_AvIng.Location = new Point(3, 37);
            dataGridView_AvIng.Name = "dataGridView_AvIng";
            dataGridView_AvIng.RowHeadersWidth = 62;
            dataGridView_AvIng.Size = new Size(479, 515);
            dataGridView_AvIng.TabIndex = 6;
            dataGridView_AvIng.CellContentClick += dataGridView_AvIng_CellContentClick;
            // 
            // dataGridView_SelIng
            // 
            dataGridView_SelIng.AllowUserToAddRows = false;
            dataGridView_SelIng.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_SelIng.Dock = DockStyle.Fill;
            dataGridView_SelIng.Location = new Point(488, 37);
            dataGridView_SelIng.Name = "dataGridView_SelIng";
            dataGridView_SelIng.RowHeadersWidth = 62;
            dataGridView_SelIng.Size = new Size(480, 515);
            dataGridView_SelIng.TabIndex = 7;
            dataGridView_SelIng.CellContentClick += dataGridView_SelIng_CellContentClick;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(479, 34);
            label3.TabIndex = 8;
            label3.Text = "Available Ingredients:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(488, 0);
            label4.Name = "label4";
            label4.Size = new Size(480, 34);
            label4.TabIndex = 9;
            label4.Text = "Selected Ingredients:";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.5814648F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80.41853F));
            tableLayoutPanel1.Controls.Add(txtName, 1, 0);
            tableLayoutPanel1.Controls.Add(txtDescription, 1, 1);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label2, 0, 1);
            tableLayoutPanel1.Location = new Point(14, 10);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(678, 95);
            tableLayoutPanel1.TabIndex = 10;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(dataGridView_AvIng, 0, 1);
            tableLayoutPanel2.Controls.Add(dataGridView_SelIng, 1, 1);
            tableLayoutPanel2.Controls.Add(CreateButton, 1, 2);
            tableLayoutPanel2.Controls.Add(label3, 0, 0);
            tableLayoutPanel2.Controls.Add(label4, 1, 0);
            tableLayoutPanel2.Location = new Point(14, 675);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 3;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 5.524862F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 83.9779F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 10.4972372F));
            tableLayoutPanel2.Size = new Size(971, 621);
            tableLayoutPanel2.TabIndex = 11;
            // 
            // pictureBoxDish
            // 
            pictureBoxDish.Dock = DockStyle.Fill;
            pictureBoxDish.Location = new Point(317, 3);
            pictureBoxDish.Name = "pictureBoxDish";
            pictureBoxDish.Size = new Size(651, 483);
            pictureBoxDish.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxDish.TabIndex = 12;
            pictureBoxDish.TabStop = false;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32.3377953F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 67.6622F));
            tableLayoutPanel3.Controls.Add(pictureBoxDish, 1, 0);
            tableLayoutPanel3.Controls.Add(btnBrowse, 0, 0);
            tableLayoutPanel3.Controls.Add(btnRemovePic, 0, 1);
            tableLayoutPanel3.Location = new Point(16, 118);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 90.221405F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 9.778598F));
            tableLayoutPanel3.Size = new Size(971, 542);
            tableLayoutPanel3.TabIndex = 13;
            // 
            // btnBrowse
            // 
            btnBrowse.Dock = DockStyle.Bottom;
            btnBrowse.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnBrowse.Location = new Point(3, 440);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(308, 46);
            btnBrowse.TabIndex = 13;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = true;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // btnRemovePic
            // 
            btnRemovePic.Dock = DockStyle.Top;
            btnRemovePic.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnRemovePic.Location = new Point(3, 492);
            btnRemovePic.Name = "btnRemovePic";
            btnRemovePic.Size = new Size(308, 47);
            btnRemovePic.TabIndex = 14;
            btnRemovePic.Text = "Remove picture";
            btnRemovePic.UseVisualStyleBackColor = true;
            btnRemovePic.Click += btnRemovePic_Click;
            // 
            // DishAddForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1012, 1319);
            Controls.Add(tableLayoutPanel3);
            Controls.Add(tableLayoutPanel2);
            Controls.Add(tableLayoutPanel1);
            Margin = new Padding(4, 5, 4, 5);
            MinimumSize = new Size(1025, 1375);
            Name = "DishAddForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DishAddForm";
            Load += MealAddForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_AvIng).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_SelIng).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxDish).EndInit();
            tableLayoutPanel3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TextBox txtName;
        private TextBox txtDescription;
        private Label label1;
        private Label label2;
        private Button CreateButton;
        private DataGridView dataGridView_AvIng;
        private DataGridView dataGridView_SelIng;
        private Label label3;
        private Label label4;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private PictureBox pictureBoxDish;
        private TableLayoutPanel tableLayoutPanel3;
        private Button btnRemovePic;
        private Button btnBrowse;
    }
}