﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class DishEditForm : Form
    {
        private int mealID;
        public DishEditForm(int mealID, string name, string description, byte[] pictureData)
        {
            InitializeComponent();

            this.mealID = mealID;
            txtName.Text = name;
            txtDescription.Text = description;

            if (pictureData != null && pictureData.Length > 0)
            {
                using (MemoryStream ms = new MemoryStream(pictureData))
                {
                    pictureBoxDish.Image = Image.FromStream(ms);
                }
;
            }
        }
        private void MealEditForm_Load(object sender, EventArgs e)
        {
            Setup_dataGridView();
            LoadData_DataGridView();
            LoadSelectedIngredients(mealID);
            //dataGridView_SelIng.CellValidating += dataGridView_SelIng_CellValidating;
            //dataGridView_SelIng.CellEndEdit += dataGridView_SelIng_CellEndEdit;
        }
        private void LoadSelectedIngredients(int mealID)
        {
            dataGridView_SelIng.Rows.Clear();

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT Ingredients FROM Meals WHERE IDMeal = @IDMeal";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDmeal", mealID);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string ingredientsList = reader["Ingredients"].ToString();

                    string[] ingredients = ingredientsList.Split(',');
                    foreach (string ingredient in ingredients)
                    {
                        dataGridView_SelIng.Rows.Add(ingredient.Trim());
                    }
                }
            }
        }
        private void LoadData_DataGridView() //Loads ingredients to DataGridView for available ingredients
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT IDIngredient, Name FROM Ingredients", con);
            cmd.Parameters.AddWithValue("@IDMeal", mealID);

            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView_AvIng.DataSource = dt;

        }


        private void Setup_dataGridView()
        {
            //Available ingredients datagridview
            DataGridViewButtonColumn addButtonColumn = new DataGridViewButtonColumn();
            addButtonColumn.HeaderText = "Add Ingredient";
            addButtonColumn.Name = "AddIngredient";
            addButtonColumn.Text = "+";
            addButtonColumn.Width = 100;
            addButtonColumn.UseColumnTextForButtonValue = true;

            dataGridView_AvIng.Columns.Add(addButtonColumn);

            //Selected ingredients datagridview
            dataGridView_SelIng.Columns.Clear();
            dataGridView_SelIng.AutoGenerateColumns = true;

            DataGridViewTextBoxColumn ingredientNameColumn = new DataGridViewTextBoxColumn();
            ingredientNameColumn.HeaderText = "Name";
            ingredientNameColumn.Name = "IngredientName";
            ingredientNameColumn.Width = 100;
            dataGridView_SelIng.Columns.Add(ingredientNameColumn);

            //Amount column
            //DataGridViewTextBoxColumn amountColumn = new DataGridViewTextBoxColumn();
            //amountColumn.HeaderText = "Amount";
            //amountColumn.Name = "Amount";
            //amountColumn.Width = 150;
            //dataGridView_SelIng.Columns.Add(amountColumn);

            //remove button column
            DataGridViewButtonColumn removeButtonColumn = new DataGridViewButtonColumn();
            removeButtonColumn.HeaderText = "Remove";
            removeButtonColumn.Name = "RemoveIngredient";
            removeButtonColumn.Text = "X";
            removeButtonColumn.UseColumnTextForButtonValue = true;
            dataGridView_SelIng.Columns.Add(removeButtonColumn);

            dataGridView_SelIng.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        //private void dataGridView_SelIng_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        //{
        //    if (dataGridView_SelIng.Columns[e.ColumnIndex].Name == "Amount")
        //    {
        //        string inputValue = e.FormattedValue.ToString();

        //        if (string.IsNullOrEmpty(inputValue))
        //        {
        //            MessageBox.Show("Please enter amount for the ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //            e.Cancel = true;
        //        }
        //    }
        //}

        //private void dataGridView_SelIng_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (dataGridView_SelIng.Columns[e.ColumnIndex].Name == "Amount")
        //    {
        //        string rawInput = dataGridView_SelIng.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString() ?? "";
        //        string formattedInput = rawInput.Replace(" ", "");

        //        dataGridView_SelIng.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = formattedInput;
        //    }
        //}

        private void dataGridView_SelIng_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView_SelIng.Columns["RemoveIngredient"].Index && e.RowIndex >= 0)
            {
                dataGridView_SelIng.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void dataGridView_AvIng_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView_AvIng.Columns["AddIngredient"].Index && e.RowIndex >= 0)
            {
                string ingredientName = dataGridView_AvIng.Rows[e.RowIndex].Cells["Name"].Value.ToString();

                bool alreadyAdded = false;
                foreach (DataGridViewRow row in dataGridView_SelIng.Rows)
                {
                    if (row.Cells["IngredientName"].Value?.ToString() == ingredientName)
                    {
                        alreadyAdded = true;
                        break;
                    }
                }
                if (!alreadyAdded)
                {
                    dataGridView_SelIng.Rows.Add(ingredientName);
                }
            }
        }

        private void SaveEdit_Button_Click(object sender, EventArgs e)
        {
            string mealName = txtName.Text;
            string mealDesc = txtDescription.Text;
            byte[] pictureData = GetImageBytes();

            if (string.IsNullOrEmpty(mealName))
            {
                MessageBox.Show("Please enter a name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dataGridView_SelIng.Rows.Count == 0)
            {
                MessageBox.Show("Please select at least 1 ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //foreach (DataGridViewRow row in dataGridView_SelIng.Rows)
            //{
            //    var amountCell = row.Cells["Amount"].Value;
            //    if (amountCell == null || string.IsNullOrWhiteSpace(amountCell.ToString()))
            //    {
            //        MessageBox.Show("Please enter the amount for each ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //        return;
            //    }
            //}

            //string ingredientsList = string.Join(", ", dataGridView_SelIng.Rows
            //    .Cast<DataGridViewRow>()
            //    .Where(row => row.Cells["IngredientName"].Value != null && row.Cells["Amount"].Value != null)
            //    .Select(row => $"{row.Cells["Amount"].Value} {row.Cells["IngredientName"].Value}"));

            string ingredientsList = string.Join(", ", dataGridView_SelIng.Rows
                .Cast<DataGridViewRow>()
                .Where(row => row.Cells["IngredientName"].Value != null)
                .Select(row => row.Cells["IngredientName"].Value.ToString()));

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                con.Open();
                SqlTransaction transaction = con.BeginTransaction();
                try
                {
                    string updateMealQuery = "UPDATE Meals SET Name = @Name, Description = @Description, Ingredients = @Ingredients, Picture = @Picture WHERE IDMeal = @IDMeal";
                    SqlCommand cmdMeal = new SqlCommand(updateMealQuery, con, transaction);
                    cmdMeal.Parameters.AddWithValue("@IDMeal", mealID);
                    cmdMeal.Parameters.AddWithValue("@Name", mealName);
                    cmdMeal.Parameters.AddWithValue("@Description", mealDesc);
                    cmdMeal.Parameters.AddWithValue("@Ingredients", ingredientsList);
                    cmdMeal.Parameters.AddWithValue("@Picture", (object)pictureData ?? DBNull.Value);

                    cmdMeal.ExecuteNonQuery();

                    transaction.Commit();
                    MessageBox.Show("Meal updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Error updating meal: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private byte[] GetImageBytes()
        {
            if (pictureBoxDish.Image == null)
                return null;

            using (MemoryStream ms = new MemoryStream())
            {
                pictureBoxDish.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp",
                Title = "Select a picture"
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxDish.Image = Image.FromFile(ofd.FileName);
            }
        }

        private void btnRemovePic_Click(object sender, EventArgs e)
        {
            if (pictureBoxDish != null)
            {
                pictureBoxDish.Image.Dispose();
                pictureBoxDish.Image = null;
            }
        }
    }
}
