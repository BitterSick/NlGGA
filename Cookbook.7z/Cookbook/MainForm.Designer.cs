﻿namespace Ingredients
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label5 = new Label();
            contextMenuStrip1 = new ContextMenuStrip(components);
            addNewToolStripMenuItem = new ToolStripMenuItem();
            editTableToolStripMenuItem = new ToolStripMenuItem();
            deleteToolStripMenuItem1 = new ToolStripMenuItem();
            addRecipeToolStripMenuItem1 = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1 = new MenuStrip();
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem5 = new ToolStripMenuItem();
            mealToolStripMenuItem = new ToolStripMenuItem();
            listToolStripMenuItem = new ToolStripMenuItem();
            createNewToolStripMenuItem = new ToolStripMenuItem();
            viewToolStripMenuItem = new ToolStripMenuItem();
            ingredientsToolStripMenuItem = new ToolStripMenuItem();
            recipesToolStripMenuItem = new ToolStripMenuItem();
            addRecipeToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            toolStripTextBox1 = new ToolStripDropDownMenu();
            panelContainer = new Panel();
            tlpCookingRec = new TableLayoutPanel();
            DGV_Available = new DataGridView();
            DGV_Selected = new DataGridView();
            btFindDish = new Button();
            btnReset = new Button();
            tlpSearch = new TableLayoutPanel();
            txtSearch = new TextBox();
            btnCookingRec = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            Dishes_DataGridView = new DataGridView();
            contextMenuStrip1.SuspendLayout();
            menuStrip1.SuspendLayout();
            panelContainer.SuspendLayout();
            tlpCookingRec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_Available).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGV_Selected).BeginInit();
            tlpSearch.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Dishes_DataGridView).BeginInit();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label5.Location = new Point(79, 306);
            label5.Name = "label5";
            label5.Size = new Size(0, 36);
            label5.TabIndex = 5;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { addNewToolStripMenuItem, editTableToolStripMenuItem, deleteToolStripMenuItem1, addRecipeToolStripMenuItem1, exitToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(207, 164);
            // 
            // addNewToolStripMenuItem
            // 
            addNewToolStripMenuItem.Name = "addNewToolStripMenuItem";
            addNewToolStripMenuItem.Size = new Size(206, 32);
            addNewToolStripMenuItem.Text = "Add new";
            addNewToolStripMenuItem.Click += addNewToolStripMenuItem_Click;
            // 
            // editTableToolStripMenuItem
            // 
            editTableToolStripMenuItem.Name = "editTableToolStripMenuItem";
            editTableToolStripMenuItem.Size = new Size(206, 32);
            editTableToolStripMenuItem.Text = "Edit table";
            editTableToolStripMenuItem.Click += editTableToolStripMenuItem_Click;
            // 
            // deleteToolStripMenuItem1
            // 
            deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
            deleteToolStripMenuItem1.Size = new Size(206, 32);
            deleteToolStripMenuItem1.Text = "Delete";
            deleteToolStripMenuItem1.Click += deleteToolStripMenuItem1_Click;
            // 
            // addRecipeToolStripMenuItem1
            // 
            addRecipeToolStripMenuItem1.Name = "addRecipeToolStripMenuItem1";
            addRecipeToolStripMenuItem1.Size = new Size(206, 32);
            addRecipeToolStripMenuItem1.Text = "Add recipe";
            addRecipeToolStripMenuItem1.Click += addRecipeToolStripMenuItem1_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(206, 32);
            exitToolStripMenuItem.Text = "Exit Application";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { toolStripMenuItem1, mealToolStripMenuItem, viewToolStripMenuItem, recipesToolStripMenuItem, toolStripMenuItem2 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1940, 33);
            menuStrip1.TabIndex = 20;
            menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem5 });
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(85, 29);
            toolStripMenuItem1.Text = "System";
            // 
            // toolStripMenuItem5
            // 
            toolStripMenuItem5.Name = "toolStripMenuItem5";
            toolStripMenuItem5.Size = new Size(141, 34);
            toolStripMenuItem5.Text = "E&xit";
            // 
            // mealToolStripMenuItem
            // 
            mealToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { listToolStripMenuItem, createNewToolStripMenuItem });
            mealToolStripMenuItem.Name = "mealToolStripMenuItem";
            mealToolStripMenuItem.Size = new Size(80, 29);
            mealToolStripMenuItem.Text = "Dishes";
            // 
            // listToolStripMenuItem
            // 
            listToolStripMenuItem.Name = "listToolStripMenuItem";
            listToolStripMenuItem.Size = new Size(201, 34);
            listToolStripMenuItem.Text = "List";
            listToolStripMenuItem.Click += listToolStripMenuItem_Click;
            // 
            // createNewToolStripMenuItem
            // 
            createNewToolStripMenuItem.Name = "createNewToolStripMenuItem";
            createNewToolStripMenuItem.Size = new Size(201, 34);
            createNewToolStripMenuItem.Text = "Create new";
            createNewToolStripMenuItem.Click += createNewToolStripMenuItem_Click;
            // 
            // viewToolStripMenuItem
            // 
            viewToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ingredientsToolStripMenuItem });
            viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            viewToolStripMenuItem.Size = new Size(117, 29);
            viewToolStripMenuItem.Text = "Ingredients";
            // 
            // ingredientsToolStripMenuItem
            // 
            ingredientsToolStripMenuItem.Name = "ingredientsToolStripMenuItem";
            ingredientsToolStripMenuItem.Size = new Size(234, 34);
            ingredientsToolStripMenuItem.Text = "Ingredients List";
            ingredientsToolStripMenuItem.Click += ingredientsToolStripMenuItem_Click;
            // 
            // recipesToolStripMenuItem
            // 
            recipesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addRecipeToolStripMenuItem });
            recipesToolStripMenuItem.Name = "recipesToolStripMenuItem";
            recipesToolStripMenuItem.Size = new Size(87, 29);
            recipesToolStripMenuItem.Text = "Recipes";
            // 
            // addRecipeToolStripMenuItem
            // 
            addRecipeToolStripMenuItem.Name = "addRecipeToolStripMenuItem";
            addRecipeToolStripMenuItem.Size = new Size(200, 34);
            addRecipeToolStripMenuItem.Text = "Add recipe";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(16, 29);
            // 
            // toolStripTextBox1
            // 
            toolStripTextBox1.AutoClose = false;
            toolStripTextBox1.ImageScalingSize = new Size(24, 24);
            toolStripTextBox1.Name = "toolStripTextBox1";
            toolStripTextBox1.Size = new Size(61, 4);
            // 
            // panelContainer
            // 
            panelContainer.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelContainer.Controls.Add(tlpCookingRec);
            panelContainer.Controls.Add(tlpSearch);
            panelContainer.Controls.Add(tableLayoutPanel1);
            panelContainer.Controls.Add(label5);
            panelContainer.Location = new Point(7, 40);
            panelContainer.Name = "panelContainer";
            panelContainer.Size = new Size(1921, 1292);
            panelContainer.TabIndex = 21;
            // 
            // tlpCookingRec
            // 
            tlpCookingRec.ColumnCount = 2;
            tlpCookingRec.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlpCookingRec.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlpCookingRec.Controls.Add(DGV_Available, 0, 1);
            tlpCookingRec.Controls.Add(DGV_Selected, 1, 1);
            tlpCookingRec.Controls.Add(btFindDish, 1, 2);
            tlpCookingRec.Controls.Add(btnReset, 0, 2);
            tlpCookingRec.Location = new Point(760, 6);
            tlpCookingRec.Name = "tlpCookingRec";
            tlpCookingRec.RowCount = 3;
            tlpCookingRec.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlpCookingRec.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpCookingRec.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlpCookingRec.Size = new Size(826, 561);
            tlpCookingRec.TabIndex = 14;
            // 
            // DGV_Available
            // 
            DGV_Available.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Available.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV_Available.Dock = DockStyle.Fill;
            DGV_Available.Location = new Point(3, 59);
            DGV_Available.Name = "DGV_Available";
            DGV_Available.RowHeadersWidth = 62;
            DGV_Available.Size = new Size(407, 442);
            DGV_Available.TabIndex = 0;
            DGV_Available.CellContentClick += DGV_Available_CellContentClick;
            // 
            // DGV_Selected
            // 
            DGV_Selected.AllowUserToAddRows = false;
            DGV_Selected.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            DGV_Selected.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Selected.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV_Selected.Location = new Point(416, 59);
            DGV_Selected.Name = "DGV_Selected";
            DGV_Selected.RowHeadersWidth = 62;
            DGV_Selected.Size = new Size(407, 442);
            DGV_Selected.TabIndex = 8;
            DGV_Selected.CellContentClick += DGV_Selected_CellContentClick;
            // 
            // btFindDish
            // 
            btFindDish.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btFindDish.BackColor = SystemColors.ActiveBorder;
            btFindDish.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btFindDish.Location = new Point(416, 507);
            btFindDish.Name = "btFindDish";
            btFindDish.Size = new Size(407, 51);
            btFindDish.TabIndex = 9;
            btFindDish.Text = "Find dish";
            btFindDish.UseVisualStyleBackColor = false;
            btFindDish.Click += btFindDish_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = SystemColors.ActiveBorder;
            btnReset.Dock = DockStyle.Fill;
            btnReset.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReset.Location = new Point(3, 507);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(407, 51);
            btnReset.TabIndex = 10;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = false;
            btnReset.Click += btnReset_Click;
            // 
            // tlpSearch
            // 
            tlpSearch.ColumnCount = 2;
            tlpSearch.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlpSearch.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 139F));
            tlpSearch.Controls.Add(txtSearch, 0, 0);
            tlpSearch.Controls.Add(btnCookingRec, 1, 0);
            tlpSearch.Location = new Point(6, 6);
            tlpSearch.Name = "tlpSearch";
            tlpSearch.RowCount = 1;
            tlpSearch.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tlpSearch.Size = new Size(745, 82);
            tlpSearch.TabIndex = 13;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtSearch.CausesValidation = false;
            txtSearch.Location = new Point(3, 3);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(600, 31);
            txtSearch.TabIndex = 0;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // btnCookingRec
            // 
            btnCookingRec.BackColor = SystemColors.ScrollBar;
            btnCookingRec.Dock = DockStyle.Fill;
            btnCookingRec.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCookingRec.Location = new Point(609, 3);
            btnCookingRec.Name = "btnCookingRec";
            btnCookingRec.Size = new Size(133, 76);
            btnCookingRec.TabIndex = 1;
            btnCookingRec.Text = "What to cook?";
            btnCookingRec.UseVisualStyleBackColor = false;
            btnCookingRec.Click += btnCookingRec_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(Dishes_DataGridView, 0, 0);
            tableLayoutPanel1.Location = new Point(9, 573);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(1900, 700);
            tableLayoutPanel1.TabIndex = 12;
            // 
            // Dishes_DataGridView
            // 
            Dishes_DataGridView.AllowUserToOrderColumns = true;
            Dishes_DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Dishes_DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Dishes_DataGridView.ContextMenuStrip = contextMenuStrip1;
            Dishes_DataGridView.Dock = DockStyle.Fill;
            Dishes_DataGridView.Location = new Point(3, 3);
            Dishes_DataGridView.Name = "Dishes_DataGridView";
            Dishes_DataGridView.ReadOnly = true;
            Dishes_DataGridView.RowHeadersWidth = 62;
            Dishes_DataGridView.Size = new Size(1894, 694);
            Dishes_DataGridView.TabIndex = 11;
            Dishes_DataGridView.CellContentClick += dataGridView1_CellContentClick;
            Dishes_DataGridView.CellMouseDown += dataGridView1_CellMouseDown;
            Dishes_DataGridView.MouseDown += dataGridView1_MouseDown;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1940, 1344);
            Controls.Add(panelContainer);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MinimumSize = new Size(1637, 1398);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            Load += MainForm_Load;
            contextMenuStrip1.ResumeLayout(false);
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            panelContainer.ResumeLayout(false);
            panelContainer.PerformLayout();
            tlpCookingRec.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DGV_Available).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGV_Selected).EndInit();
            tlpSearch.ResumeLayout(false);
            tlpSearch.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Dishes_DataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label5;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem editTableToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem1;
        private ToolStripMenuItem addNewToolStripMenuItem;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripDropDownMenu toolStripTextBox1;
        private ToolStripMenuItem ingredientsToolStripMenuItem;
        private ToolStripMenuItem mealToolStripMenuItem;
        private ToolStripMenuItem createNewToolStripMenuItem;
        private ToolStripMenuItem recipesToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem2;
        private Panel panelContainer;
        private ToolStripMenuItem listToolStripMenuItem;
        public DataGridView Dishes_DataGridView;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tlpSearch;
        private TextBox txtSearch;
        private TableLayoutPanel tlpCookingRec;
        private DataGridView DGV_Available;
        private DataGridView DGV_Selected;
        private Button btFindDish;
        private Button btnReset;
        private Button btnCookingRec;
        private ToolStripMenuItem addRecipeToolStripMenuItem1;
        private ToolStripMenuItem addRecipeToolStripMenuItem;
    }
}
