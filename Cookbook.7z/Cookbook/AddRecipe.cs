﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class AddRecipe : Form
    {
        private int dishID;
        public AddRecipe(int dishID, string dishName)
        {
            InitializeComponent();
            this.dishID = dishID;

            txtName.Text = dishName;
            LoadSelectedIngredients(dishID);
        }

        private void AddRecipe_Load(object sender, EventArgs e)
        {

            Setup_DataGridView();
        }

        private void LoadSelectedIngredients(int dishID)
        {
            dgv_ingredientsAmount.Rows.Clear();
            dgv_ingredientsAmount.Columns.Clear();

            if (dgv_ingredientsAmount.Columns.Count == 0)
            {
                dgv_ingredientsAmount.Columns.Add("IngredientName", "Name");
            }

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT Ingredients FROM Meals WHERE IDMeal = @IDMeal";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDmeal", dishID);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string ingredientsList = reader["Ingredients"].ToString();

                    string[] ingredients = ingredientsList.Split(',');
                    foreach (string ingredient in ingredients)
                    {
                        dgv_ingredientsAmount.Rows.Add(ingredient.Trim());
                    }
                }
            }
        }

        private void Setup_DataGridView()
        {
            //Amount column
            DataGridViewTextBoxColumn amountColumn = new DataGridViewTextBoxColumn();
            amountColumn.HeaderText = "Amount";
            amountColumn.Name = "Amount";
            //amountColumn.Width = 150;
            dgv_ingredientsAmount.Columns.Add(amountColumn);

            dgv_ingredientsAmount.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void dgv_ingredientsAmount_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (dgv_ingredientsAmount.Columns[e.ColumnIndex].Name == "Amount")
            {
                string inputValue = e.FormattedValue.ToString();

                if (string.IsNullOrEmpty(inputValue))
                {
                    MessageBox.Show("Please enter amount for the ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Cancel = true;
                }
            }
        }

        private void btnCreateRecipe_Click(object sender, EventArgs e)
        {
            string recipeName = txtName.Text;
            string difficulty = Diff_comboBox.SelectedItem?.ToString();
            string time = Time_comboBox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(time))
            {
                MessageBox.Show("Please select a cooking time.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            try
            {
                //using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                //{
                //    string query = "INSERT INTO Recipes (
                //}
            }
            catch (Exception ex)
            {

            }
        }
    }
}
