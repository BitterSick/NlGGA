using System.Data.SqlClient;
using System;
using System.Data;
using Microsoft.VisualBasic;
using System.Drawing;
using System.Linq.Expressions;
using System.Data.Common;
using System.Drawing.Text;
using Cookbook;
using System.Security.Cryptography;




namespace Ingredients

{
    public partial class MainForm : Form
    {
        private SqlDataAdapter dataAdapter;
        private DataTable dataTable;
        private int selectedRowIndex;
        private IngredientsList ingredientsListControl;
        public MainForm()
        {
            InitializeComponent();
            //textBox3_KeyDown += new KeyPressEventHandler(textBox3_KeyDown);
            this.ContextMenuStrip = contextMenuStrip1;

        }

        void BindData()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT * FROM Test", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            Dishes_DataGridView.DataSource = dt;
        }


        private void MainForm_Load(object sender, EventArgs e)
        {
            //BindData();
            //textBox1.Text = GetNextID().ToString();
            //RefreshData();
            LoadData_Meals();
            Dishes_DataGridView.ClearSelection();
            Dishes_DataGridView.CurrentCell = null;

            Dishes_DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            Dishes_DataGridView.Columns[0].Width = 70;
            Dishes_DataGridView.Columns[1].Width = 200;
            Dishes_DataGridView.Columns[2].Width = 300;
            Dishes_DataGridView.Columns[3].Width = 200;
            Dishes_DataGridView.Columns[4].Width = 450;
            Dishes_DataGridView.Columns[5].Width = 500;


            AddViewRecipeButtonColumn();

            SetupDataGridView();
            tlpCookingRec.Visible = false;

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    e.SuppressKeyPress = true;
            //    comboBox1.Focus();
            //    comboBox1.DroppedDown = true;
            //}
        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    e.SuppressKeyPress = true;
            //    button1.Focus();
            //}
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private int GetNextID()
        {
            int nextID = 1;
            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Test", conn))
                {
                    int count = (int)cmd.ExecuteScalar();
                    nextID = count + 1;
                }
            }
            return nextID;
        }

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    RefreshData();
        //}

        private void RefreshData()
        {
            //textBox1.Clear();
            //textBox1.Text = GetNextID().ToString();

            LoadDataIntoGrid();
        }

        private void LoadDataIntoGrid()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Test", conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    Dishes_DataGridView.DataSource = dataTable;
                }
            }
        }

        //private void button3_Click(object sender, EventArgs e)
        //{
        //SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        //con.Open();
        //string updateQuery = "UPDATE Test SET Name=@Name, Description=@Description, UnitType=@UnitType WHERE ID=@ID";
        //SqlCommand cmd = new SqlCommand(updateQuery, con);
        //cmd.Parameters.AddWithValue("@ID", int.Parse(textBox1.Text));
        //cmd.Parameters.AddWithValue("@Name", textBox2.Text);
        //cmd.Parameters.AddWithValue("@Description", textBox3.Text);
        //cmd.Parameters.AddWithValue("@UnitType", comboBox1.Text);
        //int count = cmd.ExecuteNonQuery();
        //con.Close();
        //if (count > 0)
        //{
        //    MessageBox.Show("Update Successful.", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //}
        //else
        //{
        //    MessageBox.Show("Update error.", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //}


        //}

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            //con.Open();
            //string deleteQuery = "DELETE FROM Test WHERE ID=@ID";
            //SqlCommand cmd = new SqlCommand(deleteQuery, con);
            //cmd.Parameters.AddWithValue("@ID", int.Parse(textBox1.Text));
            //int count = cmd.ExecuteNonQuery();
            //con.Close();
            //if (count > 0)
            //{
            //    MessageBox.Show("Delete Successful.", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else
            //{
            //    MessageBox.Show("Delete error.", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DishAddForm mealAddForm = new DishAddForm();
            if (mealAddForm.ShowDialog() == DialogResult.OK)
            {
                mealAddForm.Close();
                LoadData_Meals();
            }

        }

        //protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        //{
        //    if (keyData == Keys.Enter)
        //    {
        //        if (dataGridView1.Focused || dataGridView1.ContainsFocus)
        //        {
        //            button6.PerformClick();
        //            return true;
        //        }
        //    }

        //    return base.ProcessCmdKey(ref msg, keyData);
        //}

        private void FocusStyle(Button button)
        {
            button.GotFocus += (sender, e) =>
            {
                button.BackColor = Color.Aquamarine;
                button.ForeColor = Color.White;
            };

            button.LostFocus += (sender, e) =>
            {
                button.BackColor = SystemColors.Control;
                button.ForeColor = Color.Black;
            };
        }

        //private bool isEditable = false;

        //private void buttonEdit_Click(object sender, EventArgs e)
        //{
        //    isEditable = !isEditable;
        //    dataGridView1.ReadOnly = !isEditable;

        //    if (isEditable)
        //    {
        //        dataGridView1.DefaultCellStyle.BackColor = Color.White;
        //        dataGridView1.DefaultCellStyle.SelectionBackColor = Color.Blue;
        //    }
        //    else
        //    {
        //        dataGridView1.DefaultCellStyle.BackColor = Color.LightGray;
        //        dataGridView1.DefaultCellStyle.SelectionBackColor = Color.DarkGray;
        //    }
        //}

        private void editTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //int rowIndex = -1;

            //if (rowIndex >= 0)
            //{
            //    DataGridViewRow selectedRow = dataGridView1.Rows[rowIndex];

            //    int id = Convert.ToInt32(selectedRow.Cells["ID"].Value);
            //    string name = selectedRow.Cells["Name"].Value.ToString();

            //    string newName = Interaction.InputBox("Enter new name:", "Edit row", name);

            //    if (!string.IsNullOrEmpty(newName))
            //    {
            //        UpdateRowInDatabase(id, newName);
            //    }
            //}




            //string id = dataGridView1.Rows[selectedRowIndex].Cells["Id"].Value.ToString();
            //string name = dataGridView1.Rows[selectedRowIndex].Cells["Name"].Value.ToString();
            //string description = dataGridView1.Rows[selectedRowIndex].Cells["Description"].Value.ToString();
            //float price = float.Parse(dataGridView1.Rows[selectedRowIndex].Cells["Price"].Value.ToString());
            //string category = dataGridView1.Rows[selectedRowIndex].Cells["Category"].Value.ToString();
            //bool availability = (bool)dataGridView1.Rows[selectedRowIndex].Cells["Availability"].Value;


            //EditForm form3 = new EditForm(id, name, description, price, category, availability);
            //if (form3.ShowDialog() == DialogResult.OK)
            //{
            //    dataGridView1.Rows[selectedRowIndex].Cells["Name"].Value = form3.UpdatedName;
            //    dataGridView1.Rows[selectedRowIndex].Cells["Description"].Value = form3.UpdatedDescription;
            //    dataGridView1.Rows[selectedRowIndex].Cells["Price"].Value = form3.UpdatedPrice;
            //    dataGridView1.Rows[selectedRowIndex].Cells["Category"].Value = form3.UpdatedCategory;
            //    dataGridView1.Rows[selectedRowIndex].Cells["Availability"].Value = form3.UpdatedAvailability;
            //}

            if (Dishes_DataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Dishes_DataGridView.SelectedRows[0];

                int mealID = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);
                string name = selectedRow.Cells["Name"].Value.ToString();
                string description = selectedRow.Cells["Description"].Value.ToString();
                byte[] pictureData = null;
                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    string query = "SELECT Picture FROM Meals WHERE IDMeal = @IDMeal";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@IDMeal", mealID);
                        con.Open();
                        pictureData = cmd.ExecuteScalar() as byte[];
                    }
                }
                DishEditForm editForm = new DishEditForm(mealID, name, description, pictureData);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadData_Meals();
                }
            }
        }

        private void UpdateRowInDatabase(int id, string newName, string newDescription, float newPrice, string newCategory)
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string updateQuery = "UPDATE Test SET Name=@Name Description=@Description, Price=@Price, Category=@Category WHERE ID @ID";


            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                SqlCommand cmd = new SqlCommand(updateQuery, conn);
                {
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.Parameters.AddWithValue("@Name", newName);
                    cmd.Parameters.AddWithValue("@Description", newDescription);
                    cmd.Parameters.AddWithValue("@Price", newPrice);
                    cmd.Parameters.AddWithValue("@Category", newCategory);

                    try
                    {
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Rows updated successfully.");
                            RefreshData();
                        }
                        else
                        {
                            MessageBox.Show("Invalid ID");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                }
            }
        }

        private void deleteRowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Enter the ID of the row you want to delete", "Delete row", "", -1, -1);

            if (!string.IsNullOrEmpty(input) && int.TryParse(input, out int id))
            {
                DeleteRowFromDatabase(id);
            }
            else
            {
                MessageBox.Show("Invalid ID entered. Please enter a valid number");
            }
        }


        private void DeleteRowFromDatabase(int id)
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string query = "DELETE FROM Meals WHERE IDMeal = @IDMeal";

            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                //using SqlCommand cmd = new SqlConnection(connectionString); THIS CODE DOES NOT WORK
                SqlCommand cmd = new SqlCommand(query, conn);
                {
                    cmd.Parameters.AddWithValue("@IDMeal", id);

                    try
                    {
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Row deleted successfully.");
                            RefreshData();
                        }
                        else
                        {
                            MessageBox.Show("Invalid ID.");
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }

                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            int rowIndex = -1;
            if (e.Button == MouseButtons.Right)
            {
                var hit = Dishes_DataGridView.HitTest(e.X, e.Y);
                if (hit.RowIndex >= 0)
                {
                    rowIndex = hit.RowIndex;
                    Dishes_DataGridView.ClearSelection();
                    Dishes_DataGridView.Rows[hit.RowIndex].Selected = true;
                }
            }
        }

        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //if (dataGridView1.SelectedCells.Count > 0)
            //{
            //    int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;

            //    DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];

            //    int id = Convert.ToInt32(selectedRow.Cells["ID"].Value);

            //    DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this?", "Delete Row", MessageBoxButtons.YesNo);
            //    if (dialogResult == DialogResult.Yes)
            //    {
            //        DeleteRowFromDatabase(id);

            //        dataGridView1.Rows.RemoveAt(selectedRowIndex);
            //        RefreshData();
            //    }
            //    else
            //    {
            //        MessageBox.Show("No cell selected");
            //    }
            //}
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if (Dishes_DataGridView.SelectedCells.Count > 0)
            {
                if (Dishes_DataGridView.IsCurrentCellInEditMode)
                {
                    Dishes_DataGridView.EndEdit();
                }

                int selectedRowIndex = Dishes_DataGridView.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = Dishes_DataGridView.Rows[selectedRowIndex];

                if (!selectedRow.IsNewRow)
                {
                    int id = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);

                    DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this row?", "Delete Row", MessageBoxButtons.YesNo);

                    if (dialogResult == DialogResult.Yes)
                    {
                        DeleteRowFromDatabase(id);

                        //dataGridView1.Rows.RemoveAt(selectedRowIndex); - Uncommitted new row cannot be deleted

                        LoadData_Meals();
                    }
                }
                else
                {
                    MessageBox.Show("Cannot delete an uncommitted new row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("No cell selected.");
            }
            //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

            //if (dataGridView1.SelectedCells.Count > 0)
            //{
            //    if(dataGridView1.IsCurrentCellDirty)
            //    {
            //        dataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit);
            //    }

            //    int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
            //    DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];

            //    if (selectedRow.IsNewRow)
            //    {
            //        MessageBox.Show("Cannot delete an uncommitted new row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //        return;
            //    }

            //    int id = Convert.ToInt32(selectedRow.Cells["ID"].Value);

            //    DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this row?", "Delete Row", MessageBoxButtons.YesNo);
            //    if (dialogResult == DialogResult.Yes)
            //    {
            //        DeleteRowFromDatabase(id);

            //        dataGridView1.Rows.RemoveAt(selectedRowIndex);

            //        RefreshData();
            //    }
            //    else
            //    {
            //    MessageBox.Show("No cell selected.");
            //    }

            //}
        }

        public void LoadData_Meals()
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string query = "SELECT * FROM Meals";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                DataTable mealTable = new DataTable();
                adapter.Fill(mealTable);
                Dishes_DataGridView.DataSource = mealTable;
            }
        }

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Dishes_DataGridView.ClearSelection();
                Dishes_DataGridView.Rows[e.RowIndex].Selected = true;
                selectedRowIndex = e.RowIndex;

                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        //private void addToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    FormPopup form2 = new FormPopup();
        //    form2.ShowDialog();
        //}

        private void addNewToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DishAddForm mealAddForm = new DishAddForm();
            if (mealAddForm.ShowDialog() == DialogResult.OK)
            {
                LoadData_Meals();
                mealAddForm.Close();
            }
        }

        public void EndDataGridViewEdit()
        {
            Dishes_DataGridView.EndEdit();
        }

        private void addNewItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (AddForm addForm = new AddForm())
            {
                if (addForm.ShowDialog() == DialogResult.OK)
                {
                    //LoadData();
                    addForm.Close();
                }

            }
        }

        private void newBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OrderForm orderForm = new OrderForm())
            {
                if (orderForm.ShowDialog() == DialogResult.OK)
                {
                    //LoadData();
                    orderForm.Close();
                }
            }
        }

        private void ingredientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //IngList ing = new IngList();
            //if (ing.ShowDialog() == DialogResult.OK)
            //{
            //    //LoadData();

            //}
            ShowIngredientsList();
        }

        private void ShowIngredientsList()
        {
            if (ingredientsListControl == null)
            {
                ingredientsListControl = new IngredientsList();
                ingredientsListControl.CloseRequested += IngredientsList_CloseRequested;
            }

            if (!panelContainer.Controls.Contains(ingredientsListControl))
            {
                panelContainer.Controls.Add(ingredientsListControl);
                ingredientsListControl.Dock = DockStyle.Fill;
            }
            ingredientsListControl.BringToFront();
        }

        private void CloseIngredientsList()
        {
            if (ingredientsListControl != null && panelContainer.Controls.Contains(ingredientsListControl))
            {
                panelContainer.Controls.Remove(ingredientsListControl);
            }
        }

        private void createNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DishAddForm mealAddForm = new DishAddForm();
            if (mealAddForm.ShowDialog() == DialogResult.OK)
            {
                LoadData_Meals();
                mealAddForm.Close();
            }
        }

        private void AddViewRecipeButtonColumn()
        {
            DataGridViewButtonColumn viewButton = new DataGridViewButtonColumn();
            viewButton.HeaderText = "Recipe";
            viewButton.Name = "ViewRecipe";
            viewButton.Text = "View";
            viewButton.Width = 100;
            viewButton.UseColumnTextForButtonValue = true;

            Dishes_DataGridView.Columns.Add(viewButton);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == Dishes_DataGridView.Columns["ViewRecipe"].Index && e.RowIndex >= 0)
            {
                int mealID = Convert.ToInt32(Dishes_DataGridView.Rows[e.RowIndex].Cells["IDMeal"].Value);
            }
        }

        //private void LoadUserControl(UserControl control = null)
        //{
        //    panelContainer.Controls.Clear();

        //    if (control != null)
        //    {
        //        control = new MainFormUserControl();
        //    }

        //    control.Dock = DockStyle.Fill;
        //    panelContainer.Controls.Add(control);
        //    control.BringToFront();
        //}

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseIngredientsList();
        }

        private void IngredientsList_CloseRequested(object sender, EventArgs e)
        {
            ShowIngredientsList();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchValue = txtSearch.Text.Trim();

            if (Dishes_DataGridView.DataSource is BindingSource bindingSource && bindingSource.DataSource is DataTable mealTable)
            {
                if (string.IsNullOrEmpty(searchValue))
                {
                    bindingSource.RemoveFilter();
                    return;
                }
                bindingSource.Filter = $"Name LIKE '%{searchValue}%'";
            }

            else if (Dishes_DataGridView.DataSource is DataTable mealtable)
            {
                try
                {
                    if (string.IsNullOrEmpty(searchValue))
                    {
                        LoadData_Meals();
                        return;
                    }

                    var filteredData = mealtable.AsEnumerable().Where(row => row.Field<string>("Name").StartsWith(searchValue, StringComparison.OrdinalIgnoreCase));

                    if (filteredData.Any())
                    {
                        Dishes_DataGridView.DataSource = filteredData.CopyToDataTable();
                    }
                    else
                    {
                        Dishes_DataGridView.DataSource = mealtable.Clone();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error filtering dishes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SetupDataGridView()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT Name FROM Ingredients", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            DGV_Available.DataSource = dt;

            //Available ingredients datagridview
            DataGridViewButtonColumn addButtonColumn = new DataGridViewButtonColumn();
            addButtonColumn.HeaderText = "Add Ingredient";
            addButtonColumn.Name = "AddIngredient";
            addButtonColumn.Text = "+";
            addButtonColumn.Width = 100;
            addButtonColumn.UseColumnTextForButtonValue = true;
            DGV_Available.Columns.Add(addButtonColumn);

            //Selected ingredients datagridview
            DGV_Selected.Columns.Clear();
            DGV_Selected.AutoGenerateColumns = true;

            DataGridViewTextBoxColumn ingredientNameColumn = new DataGridViewTextBoxColumn();
            ingredientNameColumn.HeaderText = "Name";
            ingredientNameColumn.Name = "IngredientName";
            ingredientNameColumn.Width = 100;
            DGV_Selected.Columns.Add(ingredientNameColumn);

            DataGridViewButtonColumn removeButtonColumn = new DataGridViewButtonColumn();
            removeButtonColumn.HeaderText = "Remove";
            removeButtonColumn.Name = "RemoveIngredient";
            removeButtonColumn.Text = "X";
            removeButtonColumn.UseColumnTextForButtonValue = true;
            DGV_Selected.Columns.Add(removeButtonColumn);

            DGV_Selected.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void btFindDish_Click(object sender, EventArgs e)
        {
            if (DGV_Selected.Rows.Count < 3)
            {
                MessageBox.Show("Please select at least 3 ingredients.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedIngredients = DGV_Selected.Rows.Cast<DataGridViewRow>().Select(row => row.Cells["IngredientName"].Value?.ToString()).ToList();

            try
            {
                string query = @"SELECT * FROM Meals WHERE Ingredients LIKE @Ingredient1 
                                AND Ingredients LIKE @Ingredient2
                                AND Ingredients LIKE @Ingredient3";

                using (SqlConnection connection = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Ingredient1", "%" + selectedIngredients[0] + "%");
                    command.Parameters.AddWithValue("@Ingredient2", "%" + selectedIngredients[1] + "%");
                    command.Parameters.AddWithValue("@Ingredient3", "%" + selectedIngredients[2] + "%");

                    connection.Open();

                    DataTable resultTable = new DataTable();
                    resultTable.Load(command.ExecuteReader());

                    //display results
                    Dishes_DataGridView.DataSource = resultTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching dish recommendation: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DGV_Available_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == DGV_Available.Columns["AddIngredient"].Index && e.RowIndex >= 0)
            {
                string ingredientName = DGV_Available.Rows[e.RowIndex].Cells["Name"].Value.ToString();

                bool alreadyAdded = false;
                foreach (DataGridViewRow row in DGV_Selected.Rows)
                {
                    if (row.Cells["IngredientName"].Value?.ToString() == ingredientName)
                    {
                        alreadyAdded = true;
                        break;
                    }
                }
                if (!alreadyAdded)
                {
                    DGV_Selected.Rows.Add(ingredientName);
                }
            }
        }

        private void DGV_Selected_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == DGV_Selected.Columns["RemoveIngredient"].Index && e.RowIndex >= 0)
            {
                DGV_Selected.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                DGV_Selected.Rows.Clear();

                string query = "SELECT Name FROM Ingredients";
                DataTable availableIngredientsTable = new DataTable();

                using (SqlConnection connection = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    availableIngredientsTable.Load(command.ExecuteReader());
                }

                DGV_Available.DataSource = availableIngredientsTable;

                string queryDish = "SELECT * FROM Meals";
                DataTable dishTable = new DataTable();

                using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                using (SqlCommand cmd = new SqlCommand(queryDish, conn))
                {
                    conn.Open();
                    dishTable.Load(cmd.ExecuteReader());
                }

                Dishes_DataGridView.DataSource = dishTable;

            }

            catch (Exception ex)
            {
                MessageBox.Show("Error resetting selection: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCookingRec_Click(object sender, EventArgs e)
        {
            tlpCookingRec.Visible = !tlpCookingRec.Visible;
        }

        private void addRecipeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Dishes_DataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Dishes_DataGridView.SelectedRows[0];
                int dishID = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);
                string dishName = selectedRow.Cells["Name"].Value.ToString();

                AddRecipe recipeAdd = new AddRecipe(dishID, dishName);
                recipeAdd.ShowDialog();
            }
        }
    }
}

