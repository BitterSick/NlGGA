﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Cookbook
{
    public partial class Ingredients_AddForm : Form
    {
        private SqlDataAdapter dataAdapter;
        private DataTable dataTable;
        public System.Windows.Forms.DataGridView IngDataGridView;
        public Ingredients_AddForm()
        {
            InitializeComponent();
        }

        private void Add_OKButton_Click(object sender, EventArgs e)
        {
            string ingredientName = txtName.Text.Trim();
            if (!string.IsNullOrEmpty(ingredientName))
            {
                ingredientName = char.ToUpper(ingredientName[0]) + ingredientName.Substring(1).ToLower();
                txtName.Text = ingredientName;
            }

            if (DoesIngredientExist(ingredientName))
            {
                MessageBox.Show("This ingredient already exists in the database.", "Duplicate entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();
                    string insertQuery = "INSERT INTO Ingredients (Name, Description, UnitType, Created) VALUES (@Name, @Description, @UnitType, GETDATE())";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                        cmd.Parameters.AddWithValue("@UnitType", comboBox_UnitType.Text);

                        MessageBox.Show(cmd.ExecuteNonQuery() > 0 ? "Insert Successful." : "Insert Error.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }


                this.DialogResult = DialogResult.OK;

                this.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool DoesIngredientExist(string ingredientName)
        {
            bool exists = false;

            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT COUNT(*) FROM Ingredients WHERE Name = @Name";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", ingredientName);
                    conn.Open();
                    int count = (int)cmd.ExecuteScalar();
                    exists = (count > 0);
                }
            }
            return exists;
        }

        private void LoadData()
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string query = "SELECT * FROM Ingredients";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                dataAdapter = new SqlDataAdapter(query, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

                dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
